//Initializing my variables.
let div01 = document.getElementById("div1");
const words = ["cirro", "cumulo", "nimbo", "strato"];

//Setting up the for loop.
div01.innerHTML = words[0] + " " + words[0] + " " + words [1] + " " + words [1] + " " + words [2] + " " + words [2] + " " + words [3] + " " + words [3] + " ";
for(i = 0, i <= 2; i++;) {
    test.innerHTML = words[0] + words[0] + words [1] + words [1] + words [2] + words [2] + words [3] + words [3];
};

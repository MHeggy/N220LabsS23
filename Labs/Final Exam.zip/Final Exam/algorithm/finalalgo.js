//First, generate an array of cards from A-K of all suits.
